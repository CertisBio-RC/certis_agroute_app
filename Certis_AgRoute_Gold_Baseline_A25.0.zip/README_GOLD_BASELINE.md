
# 🟡 CERTIS AGROUTE PLANNER — GOLD BASELINE SNAPSHOT (PHASE A.25.0)
**Date:** November 2025  
**Maintainer:** John D. Bailey, PhD  
**Purpose:** Verified stable build for Certis AgRoute Planner (Next.js 15.2.4)

---
## ✅ Key Features
- Stable checkbox filtering (States, Retailers, Suppliers, Categories)
- Persistent non-destructive map filtering (CertisMap A.24.1 Gold Final)
- Static export ready for GitHub Pages (Next `output: "export"`)
- Compatible with Portable Node + PowerShell build environment

---
## 🧭 Restore Instructions
1. Unzip into your working `certis_agroute_app/` directory.
2. Copy contents into project folders as follows:
   - `/app/page.tsx`
   - `/components/CertisMap.tsx`
   - `/public/data/retailers.geojson`
3. Run:
   ```powershell
   Remove-Item -Recurse -Force .next, out
   npm run build
   npm run deploy
   ```
4. Verify live deployment at:
   `https://certisbio-rc.github.io/certis_agroute_app/`
