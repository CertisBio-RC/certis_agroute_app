// utils/token.ts
// FINAL hardcoded token for debug

export const MAPBOX_TOKEN: string =
  "pk.eyJ1IjoiZG9jamJhaWxleTE5NzEiLCJhIjoiY21ld3lzZTNqMGQwdzJxb2lwNHpjcjNveiJ9.T2O5szdwL-O5nDF9BJmFnw";
